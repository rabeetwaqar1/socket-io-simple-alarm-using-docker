Calipsa alarming system

Create docker image:

docker build -t calipsa .

Run image:

docker run -p 49160:3000 -d calipsa .


#Run with command:

npm install
npm start

